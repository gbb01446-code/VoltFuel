VoltFuel Tester Pack 0.9.4

[日本語] docs/TESTER_GUIDE.ja.md を最初にお読みください。
[English] Please read docs/TESTER_GUIDE.en.md first.

voltfuel/                  ... widget (copy to SD:/WIDGETS/)
VoltFuel-LogAnalyzer.html  ... log analyzer (open in a browser; nothing is uploaded)
docs/                      ... tester guide and support notes (ja/en)

VoltFuel is an estimate from voltage only. Do not use it as your only landing criterion.
VoltFuel は電圧だけからの推定値です。着陸判断の唯一の基準にしないでください。
